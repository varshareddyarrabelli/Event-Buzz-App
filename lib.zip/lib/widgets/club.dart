class club{

  String? name;
  String? clubhead;
  String? headmail;
  String? headphone;
  String? url;
  String? description;

  event(String name,String clubhead,String headmail,String headphone,String url,String description)
  {
    this.name=name;
    this.clubhead=clubhead;
    this.headmail=headmail;
    this.headphone=headphone;
    this.url=url;
    this.description=description;
  }

}