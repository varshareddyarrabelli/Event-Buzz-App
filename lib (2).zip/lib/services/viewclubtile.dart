import 'package:eventbuzz/models/clubclass.dart';
import 'package:eventbuzz/widgets/Home.dart';
import 'package:eventbuzz/widgets/Upcoming_Clubpage.dart';
import 'package:flutter/material.dart';

import '../widgets/Clubhome.dart';

class ClubTile1 extends StatelessWidget {

  final Clubs club;
  ClubTile1(this.club);

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(
        side: BorderSide(
          color: Color(0xff764abc),
        ),
        borderRadius: BorderRadius.circular(20.0),
      ),
      margin: EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 0.0),
      child: new InkWell(
        onTap: (){
          // print(1);
          // Clubhome(club.name);
          // Navigator.pushNamed(context, '/clubhome',arguments: club.name);
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => Clubhome(
                    club
                )),
          );
          },
            // MaterialPageRoute(
            //     builder: (context) => Clubhome(
            //      club.name
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Row(
            children: <Widget>[
              Expanded(
                flex: 4,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(width: 10,),
                    Text(
                        club.name,
                        style: TextStyle(
                          fontSize: 18.0,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        )
                    ),
                   ],
                ),
              ),
            ],
          ),),),
    );
  }
}