class heads{

  String? csname;
  String? name;
  String? email;


  heads(String csname,String name,String email,)
  {
    this.csname=csname;
    this.name=name;
    this.email=email;

  }

}